## April 2023

- Added support for looping the same video
- Player now shows the buffered/downloaded ranges of video available
- Added a 3x speed playback option
- HLS/m3u8 live vs. non-live streams are now handled properly
- Improved HLS playback experience on Safari and Android Chrome
- Pasting Reddit links with video media is now supported
- Twitch links (streams and VODs) are now supported
