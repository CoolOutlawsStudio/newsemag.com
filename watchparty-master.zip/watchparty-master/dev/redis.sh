#!/bin/bash
docker run --name watchparty-redis --rm --net=host -d redis