alter table room add column "roomTitle" text;
alter table room add column "roomDescription" text;
alter table room add column "roomTitleColor" text;